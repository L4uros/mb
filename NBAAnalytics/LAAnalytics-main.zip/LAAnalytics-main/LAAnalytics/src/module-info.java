module LAAnalytics {
	requires javafx.controls;
	requires javafx.fxml;
	
	opens usa.com.nba.atletas to javafx.graphics, javafx.fxml;
}
